"""
EPG Refresh Scheduler Plugin for Dispatcharr
Version: 1.8.3
Author: Community Plugin
"""

from .plugin import Plugin

__version__ = "1.8.3"
__all__ = ["Plugin"]
