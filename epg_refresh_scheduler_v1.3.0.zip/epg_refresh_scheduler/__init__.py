"""
EPG Refresh Scheduler Plugin for Dispatcharr
Version: 1.0.5
Author: Community Plugin
"""

from .plugin import Plugin

__version__ = "1.0.5"
__all__ = ["Plugin"]
